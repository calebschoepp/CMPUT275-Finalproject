/*
Names: Robert Mah, Caleb Schoepp
ID: 1532565, 1534577
CCID: rjmah1, cwschoep
CMPUT 275 , Winter 2019

Arduino Sudoku Solver
*/


#ifndef JOY_H
#define JOY_H

#include "consts_and_types.h"

class Joy {
public:
    bool joyPressed();
    direction joyMoved();
private:

};

#endif
